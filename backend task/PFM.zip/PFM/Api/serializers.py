from rest_framework import serializers
from . models import MyUser, Document


class RegisterSerializer(serializers.ModelSerializer):
    class Meta:
        model = MyUser
        fields = ['email','password']
    
    def validate(self,attrs):
        return attrs
    
    def create(self,validate_data):
        return MyUser.objects.create_user(**validate_data)
    

class LoginSerializer(serializers.ModelSerializer):
    email = serializers.EmailField(max_length=255)
    class Meta:
        model = MyUser
        fields = ['email','password']

class UploadSerializer(serializers.ModelSerializer):
    class Meta:
        model = Document
        fields = ['title']