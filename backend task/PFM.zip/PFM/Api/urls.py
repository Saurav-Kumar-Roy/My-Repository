from django.urls import path, include 
from . views import Register, Login, Upload

urlpatterns = [
    path('register/',Register.as_view(),name='register'),
    path('login/',Login.as_view(),name='login'),
    path('upload/',Upload.as_view(),name='upload'),
]